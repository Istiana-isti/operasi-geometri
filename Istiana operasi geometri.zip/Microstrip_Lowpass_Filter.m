% Example 8.5 Using Stubs Lowpass Filter Design

% --R--L1-----L3----- 
% |        |        |
% V        C2       RL

% 3th Degree 3.0 dB Ripple Chebyshev
g1 = 3.3487; %L1
g2 = 0.7117; %C2
g3 = 3.3487; %L3
g4 = 1.0000; %RL

% Lowpass Prototype Richards Transformation
zL1 = g1;
zC2 = 1/g2;
zL3 = g3;
z0 = 1;
display(zC2)

% Kuroda Transformation
n1 = sqrt(1+z0/zL1);
display(n1^2)
z0_new1 = zL1*n1^2;
C1_new = 1/(z0*n1^2);
zC1_new = 1/C1_new;

n3 = sqrt(1+z0/zL3);
z0_new3 = zL3*n3^2;
C3_new = 1/(z0*n3^2);
zC3_new = 1/C3_new;

% Denormalize
Z0 = 50;
Z = Z0*[zC1_new z0_new1 zC2 z0_new3 zC3_new];
display(Z)

% Line Lengths
f = 4e9; %Hz
c = 3e8; %m/s
Lambda = (c/f)*10^3; %mm
display (Lambda/8)

w = 1.1;
wc1 = 0.675;
a = 1.8*w; %curved transition
d = sqrt(a^2-w^2);
gap1 = d - wc1;

slope = d/w;
wl1 = 0.0026;
gap2 = slope*wl1;